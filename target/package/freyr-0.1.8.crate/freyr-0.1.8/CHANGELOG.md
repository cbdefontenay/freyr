# Changelog

## [0.1.4] - 10.10.2024
### Added
- Adding  a new navbar component, with an image logo instead of a **String**.

